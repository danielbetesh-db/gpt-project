# GPT Project

This repository contains a minimal **Vite + React + TypeScript** application scaffolded manually.  The file and folder structure follows the typical layout created by Vite’s official scaffolding tool.  At the root of the project there is an `index.html` file that provides the `<div id="root"></div>` mount point and references `src/main.tsx` as the entry point【712956257445946†L247-L264】.  The `src/main.tsx` file uses React’s `createRoot` API to mount the `App` component【712956257445946†L279-L287】, and the `src/App.tsx` contains a simple counter example along with links to the Vite and React documentation【712956257445946†L294-L324】.  A minimal `vite.config.ts` registers the React plugin for Vite【712956257445946†L454-L468】.

## Getting started

To run this project locally you need Node.js installed.  Follow these steps:

1. Install the dependencies (requires internet access to download packages from npm):

   ```sh
   npm install
   ```

2. Start the development server:

   ```sh
   npm run dev
   ```

   This will start Vite’s dev server and open the application in your browser.

3. Build the project for production:

   ```sh
   npm run build
   ```

For more details about the structure of a Vite React TypeScript project and explanations of the configuration files, see the Medium guide that this scaffold is based on【712956257445946†L454-L468】.